<h2>Xin chào <?= session('username') ?></h2>


<?php
	// if (hasPermission(session('userid'), 'products.create')) {
	// echo "User co quyen them san pham!";
	// } else {
	// echo "User khong co quyen them san pham!";
	// }

?>
