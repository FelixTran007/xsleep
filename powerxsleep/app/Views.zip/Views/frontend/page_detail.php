<div class="divider-area">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-12">
                <div class="divider-content" style="padding: 40px 0px 20px 0px;">
                    <h2 class="divider-title">Liên hệ</h2>
                    <div class="divider-desc" style="padding-top: 20px;">
                        <?= $page["content"] ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>