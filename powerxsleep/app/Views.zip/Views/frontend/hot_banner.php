<div class="col-sm-12 col-md-6 col-lg-4 mt-8 mt-lg-0">
    <!--== Start Product Banner Item ==-->
    <div class="product-banner-two-item">
        <div class="product-banner-two-thumb">
            <a href="shop.htmltrer"><img src="/uploads/products/s1.jpg" width="416" height="642" alt="Image-HasTech" style="height: 642px"></a>
        </div>
    </div>
    <!--== End Product Banner Item ==-->
</div>