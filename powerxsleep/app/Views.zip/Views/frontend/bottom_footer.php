<!--== Start Footer Bottom ==-->
<div class="footer-bottom">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 col-12 text-center text-md-start mt-3 mt-md-0 order-1 order-md-0">
                <p class="copyright text-white">© 2025 PowerXsleep</p>
            </div>
            <div class="col-md-6 col-12 text-center text-md-end order-0 order-md-1 mt-1 mt-md-0"></div>
        </div>
    </div>
</div>
<!--== End Footer Bottom ==-->