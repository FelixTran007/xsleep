<!--== Start Product Banner Area Wrapper ==-->
<div class="product-banner-area section-space">
    <div class="container">
        <div class="row gx-2 mb-n6">
            <div class="col-md-6 col-12 mb-4">
                <!--== Start Product Banner Item ==-->
                <div class="product-banner-item">
                    <div class="product-banner-thumb">
                        <a href="aaaaashop.html"><img src="uploads/products/s2.jpg" style="width: 645px;height: 270px;" alt="Image-HasTech"></a>
                    </div>
                </div>
                <!--== End Product Banner Item ==-->
            </div>
            <div class="col-md-6 col-12 mb-4">
                <!--== Start Product Banner Item ==-->
                <div class="product-banner-item">
                    <div class="product-banner-thumb">
                        <a href="bbbshop.html"><img src="uploads/products/s6.jpg" style="width: 645px;height: 270px;" alt="Image-HasTech"></a>
                    </div>
                </div>
                <!--== End Product Banner Item ==-->
            </div>
        </div>
    </div>
</div>
<!--== End Product Banner Area Wrapper ==-->